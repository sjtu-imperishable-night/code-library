#include <string.h>
#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include <vector>
#include <deque>
#include <queue>
#include <stack>
#include <set>
#include <map>
#include <algorithm>
#include <functional>
#include <utility>
#include <bitset>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstdio>

using namespace std;

#define REP(i,n) for((i)=0;(i)<(int)(n);(i)++)
#define snuke(c,itr) for(__typeof((c).begin()) itr=(c).begin();itr!=(c).end();itr++)

typedef long long ll;

#define MAXV 100010

int parent[MAXV],_rank[MAXV];

void init(int n){
	int i;
	REP(i,n) {parent[i] = i; _rank[i] = 1;}
}

int root(int x){
	if(parent[x] != x) parent[x] = root(parent[x]);
	return parent[x];
}

void connect(int x, int y){
	int rx=root(x),ry=root(y);
	if(rx == ry) return;
	if(_rank[rx] > _rank[ry]) {parent[ry] = rx; _rank[rx] += _rank[ry];}
	if(_rank[rx] <= _rank[ry]) {parent[rx] = ry; _rank[ry] += _rank[rx];}
}
	
int N;
int cost[100010];
vector <int> graph[100010];
vector <int> costs[100010];
	
int main(void){
	int M,i,j;
	
	cin >> N >> M;
	REP(i,N) scanf("%d", &cost[i]);
	
	init(N);
	REP(i,M){
		int a,b;
		scanf("%d%d", &a, &b);
		connect(a, b);
	}
	
	int comp = N - M;
	if(comp == 1){
		cout << 0 << endl;
		return 0;
	}
	
	REP(i,N) costs[root(i)].push_back(cost[i]);
	
	ll ans = 0;
	vector <int> v;
	
	REP(i,N) if(!costs[i].empty()){
		int sz = costs[i].size();
		sort(costs[i].begin(),costs[i].end());
		ans += costs[i][0];
		for(j=1;j<sz;j++) v.push_back(costs[i][j]);
	}
	
	sort(v.begin(),v.end());
	
	REP(i,2*(comp-1)-comp){
		if(i >= v.size()){
			cout << "Impossible" << endl;
			return 0;
		}
		ans += v[i];
	}
	
	cout << ans << endl;
	
	return 0;
}
