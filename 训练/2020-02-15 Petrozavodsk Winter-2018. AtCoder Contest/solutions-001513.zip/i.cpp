//Sugim
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <algorithm>
#if ( _WIN32 || __WIN32__ || _WIN64 || __WIN64__ )
#define INT64 "%I64d"
#else
#define INT64 "%lld"
#endif

#if ( _WIN32 || __WIN32__ || _WIN64 || __WIN64__ )
#define UNS64 "%I64u"
#else
#define UNS64 "%llu"
#endif
#include <bits/stdc++.h>
#include <random>
using namespace std;

#define rep(i, N) for (int i = 0; i < N; i++)
#define pb push_back

typedef long long ll;
typedef pair<int, int> i_i;
typedef pair<ll, int> ll_i;
typedef pair<ll, ll> ll_ll;
struct edge { int v, w; };
const ll INF = LLONG_MAX / 2;
const int MOD = 1e9 + 7;
const int e9 = 1e9;
const ll e18 = 1e18;

template <class Unko>
struct segtree {
	using T1 = typename Unko::T1;
	using T2 = typename Unko::T2;
	int N, H;
	vector<T1> a;
	vector<T2> b;
	segtree(int _N) {
		for (N = 1, H = 0; N < _N; N *= 2, H++);
		a.assign(N * 2, Unko::_id1());
		b.assign(N * 2, Unko::id2());
	}
	void up(int i) {
		while (i>>=1) {
			T1 xl = Unko::op21(b[i<<1], a[i<<1]);
			T1 xr = Unko::op21(b[i<<1 | 1], a[i<<1 | 1]);
			a[i] = Unko::op11(xl, xr);
		}
	}
	void down(int i0) {
		for (int h = H; h > 0; h--) {
			int i = i0>>h;
			a[i] = Unko::op21(b[i], a[i]);
			b[i<<1] = Unko::op22(b[i], b[i<<1]);
			b[i<<1 | 1] = Unko::op22(b[i], b[i<<1 | 1]);
			b[i] = Unko::id2();
		}
	}
	T1 get(int l, int r) {
		if (l == r) return Unko::id1();
		l += N; r += N;
		down(l); down(r - 1);
		T1 xl = Unko::id1(), xr = Unko::id1();
		for (; l < r; l>>=1, r>>=1) {
			if (l & 1) xl = Unko::op11(xl, Unko::op21(b[l], a[l])), l++;
			if (r & 1) r--, xr = Unko::op11(Unko::op21(b[r], a[r]), xr);
		}
		return Unko::op11(xl, xr);
	}
	void set(int l0, int r0, T2 y) {
		if (l0 == r0) return;
		l0 += N; r0 += N;
		down(l0); down(r0 - 1);
		for (int l = l0, r = r0; l < r; l>>=1, r>>=1) {
			if (l & 1) b[l] = Unko::op22(y, b[l]), l++;
			if (r & 1) r--, b[r] = Unko::op22(y, b[r]);
		}
		up(l0); up(r0 - 1);
	}
};

struct hoge { ll a, b, c; };

struct unko {
	using T1 = ll;
	using T2 = hoge;
	static T1 id1() { return 0; }
	static T1 _id1() { return 0; }
	static T2 id2() { return {0, 1}; }
	static T1 op11(const T1 &xl, const T1 &xr) {
		return max(xl, xr);
	}
	static T1 op21(const T2 &y, const T1 &x) {
		return (x + y.a) / y.b + y.c;
	}
	static T2 op22(const T2 &yl, const T2 &yr) {
		ll A = yr.a + yr.b * (yr.c + yl.a);
		ll B = yl.b * yr.b;
		T2 y = {A % B, B, A / B + yl.c};
		if (y.b > INT_MAX) {
			y.a = max(0LL, y.a - (y.b - INT_MAX));
			y.b = INT_MAX;
		}
		return y;
	}
};

int main() {
	int N, Q; cin >> N >> Q;
	segtree<unko> st(N);
	rep(i, N) {
		int x; scanf("%d", &x);
		st.set(i, i + 1, {x, 1, 0});
	}
	while (Q--) {
		int t, l, r, x;
		scanf("%d%d%d%d", &t, &l, &r, &x);
		r++;
		if (t == 0) st.set(l, r, {x, 1, 0});
		if (t == 1) st.set(l, r, {0, x, 0});
		if (t == 2) printf(INT64 "\n", (ll)st.get(l, r));
	}
}
