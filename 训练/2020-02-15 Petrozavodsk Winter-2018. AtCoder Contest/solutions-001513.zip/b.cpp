#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include <vector>
#include <deque>
#include <queue>
#include <stack>
#include <set>
#include <map>
#include <algorithm>
#include <functional>
#include <utility>
#include <bitset>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstdio>

using namespace std;

#define REP(i,n) for((i)=0;(i)<(int)(n);(i)++)
#define snuke(c,itr) for(__typeof((c).begin()) itr=(c).begin();itr!=(c).end();itr++)

typedef vector <int> interval;
	
char buf[200010];
	
int N;
string s;
bool FAILED = false;
vector <pair <int, int> > edges;

void add_edge(int a, int b){
	edges.push_back(make_pair(a, b));
}

vector <interval> intervals[10];

interval pop(int p){
	int sz = intervals[p].size();
	interval ans = intervals[p][sz-1];
	intervals[p].pop_back();
	return ans;
}

void add_interval(interval I){
	int p = I.size() - 1;
	intervals[p].push_back(I);
}

void reduce(int p, int q){
	interval A = pop(p);
	interval B = pop(q);
	add_edge(A[1], B[1]);
	
	int i;
	interval C,D;
	C.push_back(A[0]);
	for(i=2;i<=q;i++) C.push_back(B[i]);
	D.push_back(B[0]);
	for(i=2;i<=p;i++) D.push_back(A[i]);
	
	add_interval(C);
	add_interval(D);
}

void simplify(int p){
	interval A = pop(p);
	add_edge(A[p-4], A[p-2]);
	add_edge(A[p-3], A[p-1]);
	
	int i;
	interval B;
	for(i=0;i<=p-5;i++) B.push_back(A[i]);
	B.push_back(A[p]);
	
	add_interval(B);
}

void merge(int p, int q){
	interval A = pop(p);
	interval B = pop(q);
	add_edge(A[p], B[0]);
	
	int i;
	interval C;
	for(i=0;i<p;i++) C.push_back(A[i]);
	for(i=1;i<=q;i++) C.push_back(B[i]);
	
	add_interval(C);
}

void func(void){
	int i;
	
	while(1){
		if(intervals[3].size() >= 2){
			merge(3, 3);
		} else if(intervals[3].size() == 1){
			if(!intervals[2].empty()){
				reduce(2, 3);
			} else if(!intervals[4].empty()){
				reduce(4, 3);
			} else if(!intervals[5].empty()){
				reduce(5, 3);
			} else {
				FAILED = true;
				return;
			}
		} else if(!intervals[5].empty()){
			simplify(5);
		} else if(intervals[2].size() >= 2){
			reduce(2, 2);
		} else if(intervals[4].size() >= 2){
			reduce(4, 4);
		} else if(!intervals[2].empty() && !intervals[4].empty()){
			merge(2, 4);
		} else if(!intervals[2].empty() || !intervals[4].empty()){
			FAILED = true;
			return;
		} else {
			break;
		}
	}
	
	int sz = intervals[1].size();
	REP(i,sz) add_edge(intervals[1][(i+1)%sz][1], intervals[1][i][0]);
}

void add_interval2(interval I){
	int K,i;
	
	while(1){
		K = I.size() - 1;
		if(K < 6) break;
		int last = I[K];
		add_edge(I[K-4], I[K-2]);
		add_edge(I[K-3], I[K-1]);
		REP(i,5) I.pop_back();
		I.push_back(last);
	}
	
	intervals[K].push_back(I);
}

int color[200010];

void print(void){
	int i;
	
	if(FAILED){
		cout << "No" << endl;
	} else {
		cout << "Yes" << endl;
		REP(i,edges.size()) color[edges[i].first] = color[edges[i].second] = i + 1;
		
		int cnt = 0;
		REP(i,N) if(color[i] > 0) cnt++;
		REP(i,N) if(color[i] == 0){
			color[i] = cnt / 2 + 1;
			cnt++;
		}
		
		REP(i,N) printf("%d ", color[i]);
	}
}
	
int main(void){
	int i;
	
	cin >> N;
	N *= 2;
	scanf("%s", buf);
	s = buf;
	s = '1' + s + '1';
	
	int d = 0;
	REP(d,N) if(s[d] == '0') break;
	
	if(d == N){
		if(N % 4 == 0){
			REP(i,N/2) add_edge(i, i+N/2);
		} else {
			FAILED = true;
		}
	} else {
		vector <int> v;
		
		REP(i,N){
			if(s[(d+i+1)%N] == '1'){
				v.push_back((d+i)%N);
			} else if(!v.empty()){
				v.push_back((d+i)%N);
				add_interval2(v);
				v.clear();
			}
		}
		
		func();
	}
	
	print();
	
	return 0;
}
