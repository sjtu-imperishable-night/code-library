#if ( _WIN32 || __WIN32__ || _WIN64 || __WIN64__ )
#define INT64 "%I64d"
#else
#define INT64 "%lld"
#endif

#if ( _WIN32 || __WIN32__ || _WIN64 || __WIN64__ )
#define UNS64 "%I64u"
#else
#define UNS64 "%llu"
#endif
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cassert>
#include <algorithm>
#include <numeric>
#include <random>
#include <vector>
#include <array>
#include <bitset>
#include <queue>
#include <set>
#include <unordered_set>
#include <map>
#include <unordered_map>

using namespace std;
using uint = unsigned int;
using ll = long long;
using ull = unsigned long long;
template<class T> using V = vector<T>;
template<class T> using VV = V<V<T>>;
constexpr ll TEN(int n) { return (n==0) ? 1 : 10*TEN(n-1); }
int bsr(uint x) { return 31 - __builtin_clz(x); }
int bsr(ull x) { return 63 - __builtin_clzll(x); }
int bsf(uint x) { return __builtin_ctz(x); }
int bsf(ull x) { return __builtin_ctzll(x); }

class Crypto {
public:    
    Crypto() {
        sm = cnt = 0;
        seed();
    }

    int decode(int z) {
        z ^= next();
        z ^= (next() << 8);
        z ^= (next() << 16);
        z ^= (next() << 22);
        return z;
    }

    void query(long long z) {
        const long long B = 425481007;
        const long long MD = 1000000007;
        cnt++;
        sm = ((sm * B % MD + z) % MD + MD) % MD;
        seed();
    }
private: 
    long long sm;
    int cnt;

    uint8_t data[256];
    int I, J;

    void swap_data(int i, int j) {
        uint8_t tmp = data[i];
        data[i] = data[j];
        data[j] = tmp;    
    }

    void seed() {
        uint8_t key[8];
        for (int i = 0; i < 4; i++) {
            key[i] = (sm >> (i * 8));
        }
        for (int i = 0; i < 4; i++) {
            key[i+4] = (cnt >> (i * 8));
        }

        for (int i = 0; i < 256; i++) {
            data[i] = i;
        }
        I = J = 0;

        int j = 0;
        for (int i = 0; i < 256; i++) {
            j = (j + data[i] + key[i%8]) % 256;
            swap_data(i, j);
        }
    }

    uint8_t next() {
        I = (I+1) % 256;
        J = (J + data[I]) % 256;
        swap_data(I, J);
        return data[(data[I] + data[J]) % 256];
    }
};

ll md;

V<ll> w1, v1;
V<ll> q1, nq1;
VV<ll> q2;

int M(int x) {
    if (x >= md) return x-md;
    return x;
}
void nxt(const V<ll> &a, V<ll> &b, ll w, ll v) {
    //a + (w, v) -> b
    copy_n(begin(a), md, begin(b));
    for (int i = 0; i < md; i++) {
        b[M(i+w)] = max(b[M(i+w)], a[i]+v);
    }
}

void q1init() {
    for (int i = 0; i < md; i++) {
        q1[i] = -TEN(18);
    }
    q1[0] = 0;
}

void first() {
    q1 = V<ll>(md);
    nq1 = V<ll>(md);
    q2.push_back(V<ll>(md));
    q1init();
    for (int i = 0; i < md; i++) {
        q2[0][i] = -TEN(18);
    }
    q2[0][0] = 0;
}

void push(ll w, ll v) {
    w1.push_back(w); v1.push_back(v);
    nxt(q1, nq1, w, v);
    swap(q1, nq1);
}

void rebase() {    
    q1init();
    while (w1.size()) {
        q2.push_back(V<ll>(md));
        nxt(q2[q2.size()-2], q2.back(), w1.back(), v1.back());
        w1.pop_back(); v1.pop_back();
    }
}

void pop() {
    if (q2.size() == 1) rebase();
    q2.pop_back();
}

ll calc(const V<ll> &a, const V<ll> &b, ll l, ll r) {
    using P = pair<ll, ll>;
    deque<P> st;
    for (int i = l+md-(md-1); i < r+md-(md-1); i++) {
        // add b[i%md]
        int idx = M(i);
        while (st.size() && st.back().first <= b[idx]) st.pop_back();
        st.push_back(P(b[idx], idx));
    }
    ll ans = -TEN(18);
    for (int i = md-1; i >= 0; i--) {
        //[l+md-i, r+md-i]
        // add b[(r+md-i)%md]
        int idx = M(r+md-i);
        while (st.size() && st.back().first <= b[idx]) st.pop_back();
        st.push_back(P(b[idx], idx));
        // calc
        ans = max(ans, a[i]+st.front().first);
        // era b[(l+md-i)%md]
        idx = M(l+md-i);
        if (st.size() && st.front().second == idx) {
            st.pop_front();
        }
    }
    if (ans < 0) ans = -1;
    return ans;
}

ll calc(ll l, ll r) {
    return calc(q1, q2.back(), l, r);
}

int main() {
    scanf(INT64, &md);
    first();
    int q;
    scanf("%d", &q);
    Crypto c;
    for (int i = 0; i < q; i++) {
        int t, w, v, l, r;
        scanf("%d %d %d %d %d", &t, &w, &v, &l, &r);
        t = c.decode(t);
        w = c.decode(w);
        v = c.decode(v);
        l = c.decode(l);
        r = c.decode(r);
        w %= md;
        if (t == 1) {
            push(w, v);
        } else {
            pop();
        }
        ll z = calc(l, r);
        c.query(z);
        printf(INT64 "\n", z);
    }
    return 0;
}

