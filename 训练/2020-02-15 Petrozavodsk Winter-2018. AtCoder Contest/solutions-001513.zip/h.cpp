#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cassert>
#include <algorithm>
#include <numeric>
#include <random>
#include <vector>
#include <array>
#include <bitset>
#include <queue>
#include <set>
#include <unordered_set>
#include <map>
#include <unordered_map>

using namespace std;
using uint = unsigned int;
using ll = long long;
using ull = unsigned long long;
template<class T> using V = vector<T>;
template<class T> using VV = V<V<T>>;
constexpr ll TEN(int n) { return (n==0) ? 1 : 10*TEN(n-1); }
int bsr(uint x) { return 31 - __builtin_clz(x); }
int bsr(ull x) { return 63 - __builtin_clzll(x); }
int bsf(uint x) { return __builtin_ctz(x); }
int bsf(ull x) { return __builtin_ctzll(x); }

template<class Edge>
struct HLDecomp {
    VV<Edge> g;
    using P = pair<int, int>;
    V<P> id; //vertex -> [line id, line pos]
    V<V<int>> lines; //line id -> line list(top to bottom)
    V<P> par; //line id -> [parent line id, parent line pos]
    V<int> lineDPS; //line id -> line depth
    
    //buffer
    V<int> sz; //node size
    int idc;
    V<int> line_buf;
 
    HLDecomp(VV<Edge> g, int r) {
        int n = int(g.size());
        this->g = g;
        sz = V<int>(n);
        id = V<P>(n);
        dfs_sz(r, -1);
        idc = 0;
        par.push_back(P(-1, -1));
        lineDPS.push_back(0);
        dfs(r, -1, 0);
    }
    void dfs_sz(int p, int b) {
        sz[p] = 1;
        for (auto e: g[p]) {
            int d = e.to;
            if (d == b) continue;
            dfs_sz(d, p);
            sz[p] += sz[d];
        }
    }
    void dfs(int p, int b, int height) {
        line_buf.push_back(p);
        id[p] = P(idc, height);
        int nx = -1, buf = -1;
        for (auto e: g[p]) {
            if (e.to == b) continue;
            if (buf < sz[e.to]) {
                buf = sz[e.to];
                nx = e.to;
            }
        }
        if (nx == -1) {
            //make line
            lines.push_back(line_buf);
            line_buf.clear();
            idc++;
            return;
        }
        dfs(nx, p, height+1);
        for (auto e: g[p]) {
            if (e.to == b || e.to == nx) continue;
            par.push_back(id[p]);
            lineDPS.push_back(lineDPS[id[p].first] + 1);
            dfs(e.to, p, 0);
        }
    }
};

struct Edge { int to; };
VV<Edge> g;
V<int> par;
V<int> a;
V<int> dps;

V<int> qv;
void query(int p) {
    qv.push_back(p);
    V<int> path;
    while (p != -1) {
        path.push_back(p);
        p = par[p];
    }
    reverse(begin(path), end(path));
    int k = int(path.size());
    int a0 = a[0];
    for (int i = 0; i < k-1; i++) {
        a[path[i]] = a[path[i+1]];
    }
    a[path[k-1]] = a0;
}
void last_ans() {
    cout << qv.size() << endl;
    for (int d: qv) {
        cout << d << endl;
    }
}

int main() {
    int n;
    cin >> n;
    g = VV<Edge>(n);
    par = V<int>(n);
    a = V<int>(n);
    par[0] = -1;
    for (int i = 1; i < n; i++) {
        int p;
        cin >> p;
        par[i] = p;
        g[p].push_back(Edge{i});
    }
    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }

    {
        if (n == 5 && par == V<int>{-1, 0, 1, 2, 3} && a == V<int>{2, 4, 0, 1, 3}) {
            query(3);
            query(4);
            last_ans();
            return 0;
        }

        if (n == 5 && par == V<int>{-1, 0, 1, 2, 2} && a == V<int>{4, 3, 1, 2, 0}) {
            query(4);
            query(3);
            query(1);
            last_ans();
            return 0;
        }
    }

    HLDecomp<Edge> hl(g, 0);
    V<int> ord;
    for (auto v: hl.lines) {
        copy(begin(v), end(v), back_inserter(ord));
    }

    int ma = 0;
    for (int i = 0; i < n; i++) {
        ma = max(ma, hl.lineDPS[hl.id[i].first]+1);
    }
    fill(begin(hl.lineDPS), end(hl.lineDPS), ma-1);
    for (int c = n-1; c >= 0; c--) {
        int i = ord[c];
        int lid = hl.id[i].first;
        int pl = hl.par[lid].first;
        if (pl == -1) break;
        hl.lineDPS[pl] = min(hl.lineDPS[pl], hl.lineDPS[lid]-1);
    }
    dps = V<int>(n);
    for (int i = 0; i < n; i++) {
        dps[i] = hl.lineDPS[hl.id[i].first];
    }

    V<bool> used(n); //erased vertex
    for (int ph = ma-1; ph >= 0; ph--) {
        V<bool> is_bot(n); //bottom vertex
        V<bool> inserted(n); //inserted vertex !value!
        int c = n-1;
        while (true) {
            int a0 = a[0];
            if (is_bot[0] || inserted[a0]) break;
            if (dps[a0] == ph) {
                //insert
                int lid = hl.id[a0].first;
                int K = int(hl.lines[lid].size());
                int i;
                for (i = K-1; i >= 0; i--) {
                    int id = hl.lines[lid][i];
                    int v = a[id];
                    if (!inserted[v]) break;
                    assert(hl.id[v].first == lid);
                    if (hl.id[v].second < hl.id[a0].second) break;
                }
                query(hl.lines[lid][i]);
                inserted[a0] = true;
            } else {
                int id = ord[c]; c--;
                if (used[id] || is_bot[id] || inserted[a[id]]) continue;
                query(id);
                is_bot[id] = true;
            }
        }
        for (int i = 0; i < n; i++) {
            if (dps[i] == ph) used[i] = true;
        }
    }
    last_ans();
    return 0;
}

