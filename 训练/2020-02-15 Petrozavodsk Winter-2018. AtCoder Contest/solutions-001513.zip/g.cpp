#include <string.h>
#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include <vector>
#include <deque>
#include <queue>
#include <stack>
#include <set>
#include <map>
#include <algorithm>
#include <functional>
#include <utility>
#include <bitset>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstdio>

using namespace std;

#define REP(i,n) for((i)=0;(i)<(int)(n);(i)++)
#define snuke(c,itr) for(__typeof((c).begin()) itr=(c).begin();itr!=(c).end();itr++)

typedef long long ll;
#define MOD 1000000007ll

ll power(ll x, ll n){
	if(n == 0) return 1;
	ll y = power(x, n/2);
	y = y * y % MOD;
	if(n%2 == 1) y = y * x % MOD;
	return y;
}

ll fixed1(int a, int b, int c, int A, int B, int C){
	ll tmp = power(b, A/a) * a + power(a, B/b) * b - a * b;
	tmp = (tmp % MOD + MOD) % MOD;
	return c * power(tmp, C/c) % MOD;
}

ll fixed2(int a, int b, int c, int A, int B, int C){
	return a * b * power(c, A/a*B/b) % MOD;
}

ll C[110][110],C2[110][110];
ll cpow[10010];
ll dp[110][110];

void pre(int c){
	int i,j,k,l;
	
	REP(i,110) REP(j,i+1){
		if(j == 0 || j == i) C[i][j] = 1;
		else C[i][j] = (C[i-1][j-1] + C[i-1][j]) % MOD;
		C2[i][j] = C[i][j];
	}
	
	cpow[0] = 1;
	REP(i,10000) cpow[i+1] = cpow[i] * c % MOD;
	
	for(i=1;i<=100;i++) for(j=1;j<=100;j++){
		ll sum = cpow[i*j] - 1;
		for(k=1;k<=i;k++) for(l=1;l<=j;l++) if(k < i || l < j){
			ll tmp = C[i][k] * C[j][l] % MOD * dp[k][l] % MOD;
			sum -= tmp;
		}
		dp[i][j] = (sum % MOD + MOD) % MOD;
	}
}

int main(void){
	int a,b,c,A,B,C,i,j;
	
	cin >> a >> b >> c >> A >> B >> C;
	
	if(A % a != 0 || B % b != 0 || C % c != 0){
		cout << 0 << endl;
		return 0;
	}
	
	pre(c);
	
	ll ans = a * b * c;
	ans -= fixed2(a, b, c, A, B, C) + fixed2(b, c, a, B, C, A) + fixed2(c, a, b, C, A, B);
	ans += fixed1(a, b, c, A, B, C) + fixed1(b, c, a, B, C, A) + fixed1(c, a, b, C, A, B);
	
	ll extra = 0;
	for(i=1;i<A/a;i++) for(j=1;j<B/b;j++){
		ll coef = dp[i][j] * C2[A/a][i] % MOD * C2[B/b][j] % MOD;
		ll p = power(b, A/a-i) - 1;
		ll q = power(a, B/b-j) - 1;
		ll sum = power(p+q+1, C/c) - power(p+1, C/c) - power(q+1, C/c) + 1;
		sum = (sum + MOD) % MOD;
		extra = (extra + coef * sum) % MOD;
	}
	
	extra = extra * a * b * c % MOD;
	
	ans = (ans + extra) % MOD;
	ans = (ans + MOD) % MOD;
	cout << ans << endl;
	
	return 0;
}
