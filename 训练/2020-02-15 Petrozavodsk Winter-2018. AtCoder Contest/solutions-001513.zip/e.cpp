#include <string.h>
#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include <vector>
#include <deque>
#include <queue>
#include <stack>
#include <set>
#include <map>
#include <algorithm>
#include <functional>
#include <utility>
#include <bitset>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstdio>

using namespace std;

#define REP(i,n) for((i)=0;(i)<(int)(n);(i)++)
#define snuke(c,itr) for(__typeof((c).begin()) itr=(c).begin();itr!=(c).end();itr++)

int N;
int x[100010];
int freq[20];

bool good[(1<<16)];
int dp[(1<<16)];

void pre(void){
	int mask,mask2,i;
	
	REP(mask,(1<<16)){
		int x = 0;
		REP(i,16) if(mask&(1<<i)) x ^= i;
		if(x == 0) good[mask] = true;
	}
	
	REP(mask,(1<<16)){
		int mask2 = mask;
		while(mask2 > 0){
			if(good[mask2]) dp[mask] = max(dp[mask], dp[mask^mask2] + 1);
			mask2 = ((mask2 - 1) & mask);
		}
	}
}

int main(void){
	int i;
	
	pre();
	
	cin >> N;
	REP(i,N-1){
		int a,b,c;
		scanf("%d%d%d", &a, &b, &c);
		x[a] ^= c;
		x[b] ^= c;
	}
	
	REP(i,N) freq[x[i]]++;
	
	int groups = freq[0];
	for(i=1;i<16;i++) groups += freq[i] / 2;
	
	int mask = 0;
	for(i=1;i<16;i++) if(freq[i] % 2 == 1) mask |= (1<<i);
	groups += dp[mask];
	
	cout << N - groups << endl;
	
	return 0;
}
