#include <string.h>
#if ( _WIN32 || __WIN32__ || _WIN64 || __WIN64__ )
#define INT64 "%I64d"
#else
#define INT64 "%lld"
#endif

#if ( _WIN32 || __WIN32__ || _WIN64 || __WIN64__ )
#define UNS64 "%I64u"
#else
#define UNS64 "%llu"
#endif
#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include <vector>
#include <deque>
#include <queue>
#include <stack>
#include <set>
#include <map>
#include <algorithm>
#include <functional>
#include <utility>
#include <bitset>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstdio>

using namespace std;

#define REP(i,n) for((i)=0;(i)<(int)(n);(i)++)
#define snuke(c,itr) for(__typeof((c).begin()) itr=(c).begin();itr!=(c).end();itr++)

#define _abs(x) ((x)>0?(x):-(x))
	
typedef long long ll;
struct point {ll x,y;};

ll mod_inv(ll M, ll x){ // 1 <= x <= M-1, gcd(M, x) = 1, M^2 < LLMAX
	if(x == 1) return 1;
	ll y = mod_inv(x, M%x);
	return M - (y * (M % x) / x + M / x * y) % M;
}

point next_point(point P, point Q){
	bool swapped = false;
	if(P.x > Q.x){
		swap(P, Q);
		swapped = true;
	}
	
	ll x = Q.x - P.x;
	ll y = _abs(Q.y - P.y);
	
	ll dy = 1;
	if(y > 1) dy = mod_inv(y, x % y);
	ll dx = (dy * x - 1) / y;
	
	point ans;
	
	if(Q.y > P.y){
		ans.x = P.x + dx;
		ans.y = P.y + dy;
	} else {
		ans.x = Q.x - dx;
		ans.y = Q.y + dy;
	}
	
	if(swapped){
		ans.x = P.x + Q.x - ans.x;
		ans.y = P.y + Q.y - ans.y;
	}
	
	return ans;
}

ll area(point P, point Q, point R){
	return (Q.x - P.x) * (R.y - P.y) - (Q.y - P.y) * (R.x - P.x);
}

ll dist(point P, point Q){
	ll dx = P.x - Q.x;
	ll dy = P.y - Q.y;
	return dx * dx + dy * dy;
}

ll gcd(ll x, ll y){
	return x ? gcd(y%x, x) : y;
}

ll gcd(point P, point Q){
	ll dx = _abs(P.x - Q.x);
	ll dy = _abs(P.y - Q.y);
	return gcd(dx, dy);
}

bool check(point P, point Q, point R){
	return (area(P, Q, R) > gcd(P, Q) + gcd(Q, R) + gcd(R, P) - 2);
}

void func(point P, point Q){
	ll g = gcd(P, Q);
	P.x += (Q.x - P.x) / g;
	P.y += (Q.y - P.y) / g;
	printf(INT64 " " INT64 "\n", P.x, P.y);
}

void print(point P){
	printf(INT64 " " INT64 "\n", P.x, P.y);
}

void func(point P, point Q, point R){
	if(dist(Q, R) > dist(P, Q)){
		func(Q, R, P);
	} else if(dist(R, P) > dist(P, Q)){
		func(R, P, Q);
	} else if(gcd(P, Q) > 1){
		ll g = gcd(P, Q);
		point S = P;
		S.x += (Q.x - P.x) / g * (g/2);
		S.y += (Q.y - P.y) / g * (g/2);
		if(gcd(R, S) > 1){
			func(R, S);
		} else if(check(P, S, R)){
			func(P, S, R);
		} else {
			func(S, Q, R);
		}
	} else {
		point O = next_point(P, Q);
		printf(INT64 " " INT64 "\n", O.x, O.y);
		if(area(P, Q, O) <= 0 || area(Q, R, O) <= 0 || area(R, P, O) <= 0){
			print(P); print(Q); print(R); print(O); cout << "a" << endl;
		}
	}
}

int main(void){
	int T,t;
	point P,Q,R;
	
	srand(13123);
	
	cin >> T;
	REP(t,T){
		scanf(INT64 "" INT64 "" INT64 "" INT64 "" INT64 "" INT64, &P.x, &P.y, &Q.x, &Q.y, &R.x, &R.y);
	/*	P.x = rand() % 10;
		P.y = rand() % 10;
		Q.x = rand() % 10;
		Q.y = rand() % 10;
		R.x = rand() % 10;
		R.y = rand() % 10;
		
		if(area(P, Q, R) <= 0) continue; */
		
		if(check(P, Q, R)){
			func(P, Q, R);
		} else {
			printf("-1 -1\n");
		}
	}
	
	return 0;
}
