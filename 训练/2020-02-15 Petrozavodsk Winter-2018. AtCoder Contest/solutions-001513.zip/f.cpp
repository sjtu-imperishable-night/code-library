#include <string.h>
#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include <vector>
#include <deque>
#include <queue>
#include <stack>
#include <set>
#include <map>
#include <algorithm>
#include <functional>
#include <utility>
#include <bitset>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstdio>

using namespace std;

#define REP(i,n) for((i)=0;(i)<(int)(n);(i)++)
#define snuke(c,itr) for(__typeof((c).begin()) itr=(c).begin();itr!=(c).end();itr++)

int N;
vector <int> graph[100010];

int dfs(int p, int x){
	int i;
	
	int sum = 0;
	int zero = 0;
	
	REP(i,graph[x].size()){
		int y = graph[x][i];
		if(y != p){
			int tmp = dfs(x, y);
			sum += tmp;
			if(tmp == 0) zero++;
		}
	}
	
	int ans = sum;
	if(zero > 1) ans += zero - 1;
	
	return ans;
}

int main(void){
	int i;
	
	cin >> N;
	REP(i,N-1){
		int a,b;
		scanf("%d%d", &a, &b);
		graph[a].push_back(b);
		graph[b].push_back(a);
	}
	
	int r;
	REP(r,N) if(graph[r].size() >= 3) break;
	
	if(r == N){
		cout << 1 << endl;
		return 0;
	}
	
	int ans = dfs(-1, r);
	cout << ans << endl;
	
	return 0;
}
