#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cassert>
#include <algorithm>
#include <numeric>
#include <random>
#include <vector>
#include <array>
#include <bitset>
#include <queue>
#include <set>
#include <unordered_set>
#include <map>
#include <unordered_map>

using namespace std;
using uint = unsigned int;
using ll = long long;
using ull = unsigned long long;
template<class T> using V = vector<T>;
template<class T> using VV = V<V<T>>;
constexpr ll TEN(int n) { return (n==0) ? 1 : 10*TEN(n-1); }
int bsr(uint x) { return 31 - __builtin_clz(x); }
int bsr(ull x) { return 63 - __builtin_clzll(x); }
int bsf(uint x) { return __builtin_ctz(x); }
int bsf(ull x) { return __builtin_ctzll(x); }

template<class T>
T pow(T x, ll n, T r = 1) {
    while (n) {
        if (n & 1) r *= x;
        x *= x;
        n >>= 1;
    }
    return r;
}

template<uint MD>
struct ModInt {
    uint v;
    ModInt() : v{0} {}
    ModInt(ll v) : v{normS(v%MD+MD)} {}
    explicit operator bool() const {return v != 0;}
    static uint normS(const uint &x) {return (x<MD)?x:x-MD;};
    static ModInt make(const uint &x) {ModInt m; m.v = x; return m;}
    static ModInt inv(const ModInt &x) {return pow(ModInt(x), MD-2);} 
    ModInt operator+(const ModInt &r) const {return make(normS(v+r.v));}
    ModInt operator-(const ModInt &r) const {return make(normS(v+MD-r.v));}
    ModInt operator*(const ModInt &r) const {return make((ull)v*r.v%MD);}
    ModInt operator/(const ModInt &r) const {return *this*inv(r);}
    ModInt& operator+=(const ModInt &r) {return *this=*this+r;}
    ModInt& operator-=(const ModInt &r) {return *this=*this-r;}
    ModInt& operator*=(const ModInt &r) {return *this=*this*r;}
    ModInt& operator/=(const ModInt &r) {return *this=*this/r;}
};
template<uint MD> string to_string(ModInt<MD> m) {return to_string(m.v);}
using Mint = ModInt<TEN(9)+7>;

const int d4[4][2] = {
    {1, 0},
    {0, 1},
    {-1, 0},
    {0, -1},
};

using P = array<int, 2>;

const int MN = 1000;
int h, w;
bool g[MN][MN];
Mint wei[MN][MN];

bool used[MN][MN];
int dist[MN][MN];
Mint calc(int sx, int sy) {
    if (g[sy][sx]) return Mint(0);
    //init
    for (int i = 0; i < h; i++) {
        for (int j = 0; j < w; j++) {
            used[i][j] = false;
            dist[i][j] = TEN(9);
        }
    }

    queue<P> q;
    q.push(P{sx, sy});
    dist[sy][sx] = 0;
    Mint sm = 0;
    while (q.size()) {
        P p = q.front(); q.pop();
        int x = p[0], y = p[1];
        if (used[y][x]) continue;
        used[y][x] = true;
        sm += wei[y][x] * dist[y][x];
        for (int i = 0; i < 4; i++) {
            int nx = x + d4[i][0], ny = y + d4[i][1];
            if (!(0 <= nx && nx < w && 0 <= ny && ny < h)) continue;
            if (g[ny][nx]) continue;
            if (used[ny][nx]) continue;
            if (dist[ny][nx] <= dist[y][x]+1) continue;
            dist[ny][nx] = dist[y][x]+1;
            q.push(P{nx, ny});
        }
    }
    return sm * wei[sy][sx];
}

Mint C(Mint l, Mint r, Mint h, Mint w) {
    Mint sm = 0;
    sm += (l*r+l*w*h)*(w-1);
    sm += (r*h-l*h+w*h*h)*w*(w-1)/2;
    sm -= h*h*(w-1)*w*(w*2-1)/6;
    return sm;
}

Mint calc(V<int> di) {
    int n = int(di.size()) - 1;
    Mint sm = 0;
    Mint a = 0, b = Mint(di.back());
    for (int i = 0; i < n; i++) {
        Mint w = Mint(di[i+1]-di[i]);
        b -= w;
        sm += C(a, b, 1, w);
        a += w;
    }
    return sm;
}
int main() {
    int fh, fw;
    cin >> fh >> fw;
    int n;
    cin >> n;
    V<int> xv, yv;
    V<P> points;
    for (int i = 0; i < n; i++) {
        int y, x;
        cin >> y >> x;
        xv.push_back(x); xv.push_back(x+1);
        yv.push_back(y); yv.push_back(y+1);
        points.push_back(P{x, y});
    }
    xv.push_back(0); yv.push_back(0);
    xv.push_back(fw); yv.push_back(fh);
    sort(begin(xv), end(xv));
    sort(begin(yv), end(yv));
    xv.erase(unique(begin(xv), end(xv)), end(xv));
    yv.erase(unique(begin(yv), end(yv)), end(yv));
    
    h = int(yv.size())-1;
    w = int(xv.size())-1;
    for (auto p: points) {
        int x = lower_bound(begin(xv), end(xv), p[0]) - begin(xv);
        int y = lower_bound(begin(yv), end(yv), p[1]) - begin(yv);
        g[y][x] = true;
    }
    for (int y = 0; y < h; y++) {
        for (int x = 0; x < w; x++) {
            wei[y][x] = Mint(xv[x+1]-xv[x]) * Mint(yv[y+1]-yv[y]);
        }
    }

    Mint sm = 0;
    {
        Mint l = 0, r = Mint(fh)*Mint(fw)-Mint(n);
        for (int i = 0; i < w; i++) {
            Mint nw = xv[i+1]-xv[i];
            Mint ws = Mint(nw)*Mint(fh);
            for (int j = 0; j < h; j++) {
                if (g[j][i]) ws -= Mint(1);
            }
            r -= ws;
            sm += C(l, r, fh, nw);
            l += ws;
        }
    }
    {
        Mint l = 0, r = Mint(fh)*Mint(fw)-Mint(n);
        for (int i = 0; i < h; i++) {
            Mint nw = yv[i+1]-yv[i];
            Mint ws = Mint(nw)*Mint(fw);
            for (int j = 0; j < w; j++) {
                if (g[i][j]) ws -= Mint(1);
            }
            r -= ws;
            sm += C(l, r, fw, nw);
            l += ws;
        }
    }
    for (int y = 0; y < h; y++) {
        for (int x = 0; x < w; x++) {
            sm += calc(x, y)/2;
        }
    }
    cout << sm.v << endl;
    return 0;
}

