#include <string>
#include <vector>
#include <iostream>
#include <cassert>
#include <random>
#include <algorithm>

using namespace std;

#define sz(c) int((c).size())
#define forn(i, n) for (int i = 0; i < int(n); ++i)

int N, K, Q;
vector<string> s;

bool read() {
    if (!(cin >> N >> K >> Q)) {
        return 0;
    }

    s.clear();
    s.resize(Q);
    forn(i, Q) {
        cout << "?" << endl;
        string cur;
        cin >> cur;
        assert(sz(cur) == N);
        s[i] = cur;
    }
    return 1;
}

int dist(const string& s, const string& t) {
    int res = 0;
    assert(sz(s) == sz(t));
    forn(i, sz(s)) {
        res += s[i] != t[i];
    }
    return res;
}

bool try_cluster(int index) {
    vector<string> c(2);
    c[0] = s[index];
    c[1] = s[0];
    forn(i, Q) {
        if (dist(s[i], c[0]) > dist(c[1], c[0])) {
            c[1] = s[i];
        }
    }

    vector<vector<vector<int>>> cnt(2, vector<vector<int>>(N, vector<int>(2, 0)));
    forn(i, Q) {
        int id = 0;
        if (dist(s[i], c[id ^ 1]) < dist(s[i], c[id])) {
            id ^= 1;
        } 

        forn(j, N) {
            ++cnt[id][j][s[i][j] - '0'];
        }
    }

    vector<string> res(2, string(N, '0'));
    forn(id, 2) {
        forn(i, N) {
            if (cnt[id][i][0] > cnt[id][i][1]) {
                res[id][i] = '0';
            } else {
                res[id][i] = '1';
            }
        }
    }

    forn(i, Q) {
        if (dist(s[i], res[0]) != K && dist(s[i], res[1]) != K) {
            return 0;
        }
    }

    sort(res.begin(), res.end());
    cout << "! " << res[0] << " " << res[1] << endl;
    return 1;
}

void solve() {
    forn(i, Q) {
        bool ok = try_cluster(i);
        if (ok) {
            return;
        }
    }
    assert(0);
}

int main() {
    while (read()) {
        solve();
    }
}

