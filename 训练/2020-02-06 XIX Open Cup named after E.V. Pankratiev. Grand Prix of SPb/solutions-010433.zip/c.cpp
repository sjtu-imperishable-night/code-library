#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef long double ld;
typedef pair<int,int> pii;
#define mp make_pair
#define pb push_back
#define sz(x) ((int) (x).size())
#define db(x) cout << #x" = " << x << endl
#define db2(x,y) cout << #x" = " << x << "; " << #y" = " << y << endl
#define db3(x,y,z) cout << #x" = " << x << "; " << #y" = " << y << "; " << #z" = " << z << endl

#define X first
#define Y second

const int maxn = (int)1e5, maxk = 18;
int maskWeight[1<<maxk];
int mask[maxn];
int cliqueCost[maxk];
int pathCost[maxk][maxk];
pii ord[maxk * maxk];
int restricted[maxk], restrictedMask[1<<maxk];
int subMaskWeight[1<<maxk];

int dp[1<<maxk][maxk+1];

int main()
{
	int n, k;
	scanf("%d%d", &n, &k);
	for (int i = 0; i < (1<<k); i++) maskWeight[i] = 0;
	for (int i = 0; i < n; i++) mask[i] = 0;
	for (int i = 0; i < k; i++)
	{
		int m;
		scanf("%d%d", &cliqueCost[i], &m);
		for (int j = 0; j < m; j++)
		{
			int u;
			scanf("%d", &u);
			u--;
			mask[u] |= 1<<i;
		}
	}
	for (int i = 0; i < n; i++) 
	{
		assert(mask[i] != 0);
		maskWeight[mask[i]]++;
	}
	for (int i = 0; i < k; i++)
	   for (int j = 0; j < k; j++)
	   {
		   bool possible = maskWeight[(1<<i)|(1<<j)] > 0;
		   int bigMask = ((1<<k)-1)^(1<<i)^(1<<j);
		   for (int rm = bigMask; rm > 0 && !possible; rm = (rm - 1) & bigMask)
		      if (maskWeight[rm | (1<<i) | (1<<j)] > 0) possible = 1;
		   if (!possible) pathCost[i][j] = (int)1e9;
		   else pathCost[i][j] = (i==j?0:cliqueCost[j]);
	   }
	int floyd = 0;
	for (int g = 0; g < k; g++)
	   for (int i = 0; i < k; i++)
	      for (int j = 0; j < k; j++)
	      {
	         if (pathCost[i][j] < (int)1e9 && pathCost[i][j] > pathCost[i][g] + pathCost[g][j])
	         {
	             floyd++;
	         }
	         pathCost[i][j] = min(pathCost[i][j], pathCost[i][g] + pathCost[g][j]);
	      }
	cerr << "floyd=" << floyd << endl;
	for (int i = 0; i < k; i++)
	    for (int j = 0; j < k; j++)
	        pathCost[i][j] += cliqueCost[i];
	int pcnt = 0;
	for (int i = 0; i < k; i++)
	   for (int j = 0; j < k; j++)
	   {
		  assert(pathCost[i][j] < (int)1e9);
	      ord[pcnt++] = mp(i,j);
	   }
	sort(ord, ord + pcnt, [&](const pii &a, const pii &b) {return pathCost[a.X][a.Y] < pathCost[b.X][b.Y];});
	
	/*for (int i = 0; i < (1<<k); i++)
	{
		subMaskWeight[i] = maskWeight[0];
		for (int j = i; j > 0; j = (j-1) & i)
		   subMaskWeight[i] += maskWeight[j];		
	}*/
	for (int i = 0; i <= k; i++)
	   dp[0][i] = 0;
	for (int i = 1; i < (1<<k); i++)
	   for (int j = k; j >= 0; j--)
	   {
		   if (j == k) dp[i][j] = maskWeight[i];
		   else
		   {
			   dp[i][j] = dp[i][j+1];
			   if (i & (1<<j))
			   {
				   dp[i][j] += dp[i ^ (1<<j)][j];
			   }
		   }
	   }
	for (int i = 0; i < (1<<k); i++) subMaskWeight[i] = dp[i][0];
	for (int i = 0; i < k; i++) restricted[i] = 0;
	for (int i = 0; i < (1<<k); i++) restrictedMask[i] = 0;
	ll ans = 0;
	int all = (1<<k)-1;
	
	for (int t = 0; t < pcnt; t++)
	{
		int i = ord[t].X;
		int j = ord[t].Y;
		restrictedMask[0] = 0;
		//cout << "w(" << i << "," << j << ") = " << pathCost[i][j] << endl;
		for (int curmask = 1; curmask < (1<<k); curmask++)
		{
		//	restrictedMask[curmask] = restrictedMask[curmask&(curmask-1)] | restricted[__builtin_popcount((curmask^(curmask&(curmask-1)))-1)];
			if (!(curmask & (1<<i))) continue;
			if (restrictedMask[curmask] & (1<<j)) continue;
			//cout << "curmask=" << curmask << " restricted=" << restrictedMask[curmask] << endl;
			ans += (ll)(subMaskWeight[all^restrictedMask[curmask]] - subMaskWeight[all^restrictedMask[curmask]^(1<<j)]) 
			                      * (ll)pathCost[i][j] * (ll)maskWeight[curmask];
		}
		restricted[i] |= 1<<j;
		restrictedMask[1<<i] |= 1<<j;
		for (int curmask = (all^(1<<i)); curmask > 0; curmask = (curmask - 1) & (all ^ (1<<i)))
		   restrictedMask[curmask|(1<<i)] |= 1<<j;
	}
	
	for (int i = 1; i < (1<<k); i++)
	{
		int res = (int)1e9;
		for (int j = 0; j < k; j++)
		   if (i & (1<<j)) res = min(res, cliqueCost[j]);
		ans -= (ll)res * (ll)maskWeight[i];
	}
	assert(ans % 2ll == 0);
	cout << ans / 2ll << endl;
	//cerr << (double)clock() / CLOCKS_PER_SEC << endl;
	return 0;
}
