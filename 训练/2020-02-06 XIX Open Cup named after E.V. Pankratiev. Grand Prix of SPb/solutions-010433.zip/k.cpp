#include <cstdio>
#include <algorithm>
#include <cassert>
#include <vector>

using namespace std;

typedef long long ll;

struct Rat {
  ll a, b;
  Rat(ll _a, ll _b = 1) : a(_a), b(_b) {
    assert(b);
    ll g = __gcd(abs(a), abs(b));
    a /= g;
    b /= g;
    if (b < 0) {
      a *= -1;
      b *= -1;
    }
  }
  Rat() :a(0), b(1) {
    
  }
};

Rat operator*(const Rat &a, const Rat &b) {
  return Rat(a.a * b.a, a.b * b.b);
}
Rat operator/(const Rat &a, const Rat &b) {
  return Rat(a.a * b.b, a.b * b.a);
}
Rat operator+(const Rat &a, const Rat &b) {
  return Rat(a.a * b.b + a.b * b.a, a.b * b.b);
}
Rat operator-(const Rat &a, const Rat &b) {
  return Rat(a.a * b.b - a.b * b.a, a.b * b.b);
}

vector<vector<Rat>> v;

int main() {
  int n, m;
  scanf("%d%d", &n, &m);
  if (n == 1) {
    v.push_back({0, 1, 0, 0, 0});
    v.push_back({0, 0, 0, 1, 0});
  }
  if (m == 1) {
    v.push_back({0, 0, 1, 0, 0});
    v.push_back({0, 0, 0, 1, 0});
  }
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < m; j++) {
      char buf[20];
      scanf("%s", buf);
      if (buf[0] != '?') {
        int x;
        sscanf(buf, "%d", &x);
        v.push_back({1, i, j, i * j, x});
      }
    }
  }

  int pt = 0;

  vector<int> f;
  vector<int> id(4);

  for (int i = 0; i < 4; i++) {
    for (int j = pt; j < (int)v.size(); j++) {
      if (v[j][i].a != 0) {
        swap(v[pt], v[j]);
        break;
      }
    }
    if (pt == (int)v.size() || v[pt][i].a == 0) {
      id[i] = -1;
      f.push_back(i);
      continue;
    }
    id[i] = pt;
    for (int j = 0; j < (int)v.size(); j++) {
      if (j == pt) continue;
      Rat coef = v[j][i] / v[pt][i];
      for (int k = 0; k < 5; k++) {
        v[j][k] = v[j][k] - v[pt][k] * coef; 
      }
    }
    pt++;
  }

  for (int i = pt; i < (int)v.size(); i++) {
    if (v[i][4].a != 0) {
      printf("None\n");
      return 0;
    }
  }

  if (f.size() == 0) {
    printf("Unique\n");
  } else {
    printf("Multiple\n");
  }

  for (int value = 0; ; value++) {
    vector<Rat> ans(4);
    for (int i = 0; i < 4; i++) {
      if (id[i] == -1) {
        ans[i] = value;
      } else {
        ans[i] = v[id[i]][4] / v[id[i]][i];
        for (int k : f) {
          ans[i] = ans[i] - value * v[id[i]][k] / v[id[i]][i];
        }
      }
    }

    for (int i = 0; i < n; i++) {
      for (int j = 0; j < m; j++) {
        Rat r = ans[0] + ans[1] * i + ans[2] * j + ans[3] * i * j;
        printf("%lld/%lld ", r.a, r.b);
      }
      printf("\n");
    }
    if (value == 1) break;
    if (f.size() == 0) break;
    printf("and\n");
  }
}
