
#include "bits/stdc++.h"

using namespace std;

typedef long long int64;

#define x first
#define y second
typedef pair<int,int> pii;
const int maxn = 305000;
int s, t0, t1;
int N, m, v;
int label[maxn], go[maxn][2];
vector<int> back[maxn];
vector<int> back_type[maxn];

// Graph G
vector<int> edges[maxn];
vector<int> link[maxn];
int efrom[maxn], eto[maxn];
int c[maxn];

namespace graphG {

bool used[maxn];
int g[maxn];

void dfs(int v, int ep, int p, vector<int> &x,
         vector<int> &restrict,
	 vector<int> &c) {
  used[v] = true;
  for (int i = 0; i < (int)link[v].size(); ++i)
    if (!used[link[v][i]] && restrict[edges[v][i]] == -1) 
      dfs(link[v][i], edges[v][i], v, x, restrict, c);
  if (p == -1) return;
  if (c[v] != g[v]) {
    x[ep] ^= 1;
    g[p] ^= 1;
    g[v] ^= 1;
  }
}

void find_a_1_input(vector<int> &x) {
  vector<int> restrict(m, -1);
  vector<int> c_(v, -1);
  for (int i = 0; i < v; ++i) c_[i] = c[i];
  for (int i = 0; i < v; ++i) used[i] = false, g[i] = 0;
  dfs(0, -1, -1, x, restrict, c_);  
}

void find_a_1_input_partial(vector<int> &x, vector<int> &restrict,
			    vector<int> &c) {
  for (int i = 0; i < v; ++i) used[i] = false, g[i] = 0;
  for (int i = 0; i < v; ++i) {
    if (used[i]) continue;
    dfs(i, -1, -1, x, restrict, c);
  }
}


}


int calcEC(const vector<int> &x) {
  int start = s;  
  while (true) {
    if (go[start][0] == -1) break;
    start = go[start][x[label[start]]];
  }
  if (start == t0) return 0;
  assert(start == t1);
  return 1;
}

int calcF(const vector<int> &x) {
  bool ok = true;
  for (int i = 0; i < v && ok; ++i) {
    int odd = 0;
    for (int j = 0; j < (int)edges[i].size(); ++j)
      odd ^= x[edges[i][j]];
    if (odd != c[i]) ok = false;
  }
  return (int)ok;
}

bool reachable[maxn];

void mark_reachable(int v) {
  if (reachable[v]) return;
  //cerr << "reachable(" << v << ")" << endl;
  reachable[v] = true;
  for (int u : back[v]) mark_reachable(u);
}

int ordering[maxn];
int rev[maxn];
bool used[maxn];

int F;
void topsort(int v) {
  if (used[v]) return;
  //cerr << "topsort(" << v << ")" << endl;
  used[v] = true;
  for (int u : back[v]) topsort(u);
  ordering[F++] = v;
}

// arbitrary go to s
void go_back_arb(vector<int>& x, int v) {
  if (back[v].size() == 0) return;
  int u = back[v][0];
  if (go[u][0] == v) x[label[u]] = 0;
  if (go[u][1] == v) x[label[u]] = 1;
  go_back_arb(x, u);
}

// arbitrary go to t_1
void go_front_arb(vector<int> &x, int v) {
  if (go[v][0] == -1) return;
  //cerr << "go_front_arb(" << v << ")" << endl;
  if (reachable[go[v][0]]) {
    x[label[v]] = 0;
    go_front_arb(x, go[v][0]);
    return;
  }
  assert(reachable[go[v][1]]);
  x[label[v]] = 1;
  go_front_arb(x, go[v][1]);
}

struct DSU {
  vector<int> p;
  vector<int> rank;
  vector<int> odd;
  int time;
  
  vector<int> log_time;
  vector<int> log_id;
  vector<int> log_rank;
  vector<int> log_p;
  vector<int> log_odd;
  DSU(int n) {
    time = 0;
    p.resize(n, 0);
    for (int i = 0; i < n; ++i) p[i] = i;
    rank.resize(n, 1);
    odd.resize(n, 0);
  }
  
  void make_log(int id) {
    log_time.push_back(time);
    log_id.push_back(id);
    log_rank.push_back(rank[id]);
    log_p.push_back(p[id]);
    log_odd.push_back(odd[id]);
    time++;
  }
  
  void change_p(int id, int new_p) {
    make_log(id);
    p[id] = new_p;
  }
  void change_rank(int id, int new_rank) {
    make_log(id);
    rank[id] = new_rank;
  }
  void change_odd(int id, int new_odd) {
    make_log(id);
    odd[id] = new_odd;
  }
  
  void change_all(int id, int new_p, int new_rank, int new_odd) {
    make_log(id);
    odd[id] = new_odd;
    p[id] = new_p;
    rank[id] = new_rank;
  }
  
  void go_back(int time0) {
    while ((int)log_time.size() > 0 && log_time.back() >= time0) {
      int cur_id = log_id.back();
      rank[cur_id] = log_rank.back();
      p[cur_id] = log_p.back();
      odd[cur_id] = log_odd.back();
      log_time.pop_back();
      log_odd.pop_back();
      log_id.pop_back();
      log_p.pop_back();
      log_rank.pop_back();
    }
  }
  int getp(int v) {
    if (p[v] == v) return v;
    return getp(p[v]);
  }
  // returns true if (u,v) is a bridge
  bool add_edge(int u, int v) {
    int pu = getp(u);
    int pv = getp(v);
    if (pu == pv) return false;    
    if (rank[pv] > rank[pu]) swap(pu, pv);
    change_p(pv, pu);
    change_all(pu, p[pu], rank[pu] + rank[pv], odd[pu] ^ odd[pv]); 
    return true;     
  }
};

void find_false_negative(int v, DSU& dsu, vector<bool>& used,
                         tuple<int,int,int>& result) {
  if (used[v] || result != make_tuple(-1,-1,-1)) return;
  used[v] = true;
  int my_label = label[v];    
  int vertex_a = my_label != -1? efrom[my_label] : 0;
  int vertex_b = my_label != -1 ? eto[my_label]  :0;
  
  if (v != t1) {
  /*  cerr << "ffn(" << v << ")" << endl;
    cerr << vertex_a << ' ' << vertex_b << endl;
    set<int> U;
    for (int i = 0; i < dsu.p.size(); ++i)  {
      cout << dsu.getp(i) << ' ';
      U.insert(dsu.getp(i));
    }
    cout << endl;
    for (int u: U) cout << u << ": " << dsu.odd[u] << endl;*/
    // we know that at node v we do not have odd components yet
    // so in order to check if there are any odd components we only
    // need to check if the components of vertex_a and vertex_b are odd.
    for (int j = 0; j < 2; ++j) {
      int to = go[v][j];
      if (!reachable[to]) {
	if (dsu.getp(vertex_a) == dsu.getp(vertex_b))  {
	  result = make_tuple(v, to, j);
	  return;
	}
      }
    }
  }
  int current_time = dsu.time;
  if (v != t1) dsu.add_edge(vertex_a, vertex_b);  
  for (int u : back[v]) find_false_negative(u, dsu, used, result);  
  dsu.go_back(current_time);  
}


int64 edge_set_hash[maxn];
int64 labels_hash[maxn];
int64 weight[maxn];

int main() {
  assert(scanf("%d%d%d%d%d", &N, &m, &s, &t0, &t1) == 5);
  t0--;
  t1--;
  s--;
  for (int i = 0; i < N; ++i) {
    assert(scanf("%d%d%d", &go[i][0], &go[i][1], &label[i]) == 3);
    for (int j = 0; j  < 2; ++j) {
      if (go[i][j] > 0) {
        go[i][j]--;
	back[go[i][j]].push_back(i);
	back_type[go[i][j]].push_back(j);
	
      }
    }  
    label[i]--;
  }
  assert(scanf("%d", &v) == 1);
  for (int i = 0; i < v; ++i) assert(scanf("%d", &c[i]) == 1);
  int whole_xor = 0;
  for (int i = 0; i < v; ++i) whole_xor ^= c[i];
  for (int i = 0; i < v; ++i) edges[i].clear();
  for (int i = 0; i < m; ++i) {
    int a,b;
    assert(scanf("%d%d", &a, &b) == 2);
    a--; b--;
    efrom[i] = a; eto[i] = b;
    edges[a].push_back(i);
    edges[b].push_back(i);
    link[a].push_back(b);
    link[b].push_back(a);
  }
  //cerr << "READ" << endl;
  for (int i = 0; i < N; ++i) reachable[i] = false;
  mark_reachable(t1);
  // reachable vertices (i.e. the ones from which one can go to t_1)
  // have to have consistent inner paths.
  F = 0;
  topsort(t0);
  topsort(t1);
  //cerr << "SORTED" << endl;
  
  for (int i = 0; i < N; ++i) rev[ordering[i]] = i;
  weight[0] = 1;
  for (int i = 0; i <= max(m, v); ++i) 
    weight[i] = weight[i-1] * 3ll + 17ll;
  
  if (ordering[0] != s) swap(ordering[0], ordering[rev[s]]);
  for (int i = 0; i < N; ++i) rev[ordering[i]] = i;
  edge_set_hash[s] = 0;
  labels_hash[s] = 0;
  for (int i = 0; i < v; ++i) 
    if (c[i]) labels_hash[s] ^= weight[i];
    
  for (int _i = 1; _i < N; ++_i) {
    int i = ordering[_i];
    if (back[i].empty()) {
      if (i != t0 && i != t1) assert(false);
      if (i == t0 || (i == t1 && whole_xor == 0)) {
	cout << "NO\n";
	vector<int> x(m, 0);
	graphG::find_a_1_input(x);
	// found a 1 input and xored one edge, got 0-input.
	if (i == t0) x[0] ^= 1;
	for (int i = 0; i < m; ++i) cout << x[i];
	cout << endl;
	return 0;
      }
      if (i == t1) {
	assert(whole_xor == 1);
	cout << "YES\n";
	return 0;
      }
    }
    assert(!back[i].empty());
    edge_set_hash[i] = edge_set_hash[back[i][0]] 
                       ^ weight[label[back[i][0]]];
    bool by_one = back_type[i][0];
    labels_hash[i] = labels_hash[back[i][0]] ^
                     (by_one ? weight[efrom[label[back[i][0]]]] ^
		     weight[eto[label[back[i][0]]]] : 0ll);
    //cerr << "lh[" << i << "] = " << labels_hash[i] << "\n";
    //cerr << "_i=" << _i << endl;
    if (!reachable[i]) continue;
    for (int j = 1; j < (int)back[i].size(); ++j) {
      bool by_one = back_type[i][j];    
      int64 my_edge_hash = edge_set_hash[back[i][j]] 
                       ^ weight[label[back[i][j]]];
      int64 my_labels_hash = labels_hash[back[i][j]] ^
                     (by_one ? weight[efrom[label[back[i][j]]]] ^
		     weight[eto[label[back[i][j]]]] : 0ll);
      if (my_edge_hash != edge_set_hash[i] ||
          my_labels_hash != labels_hash[i]) {
	// here we need to find two paths:
	// s ---> back[i][0] -> i ---> t1
	// s ---> back[i][j] -> i ---> t2
	// one of them is a counterexample
	vector<int> x1(m);
	vector<int> x2(m);
	go_back_arb(x1, back[i][0]);
	go_back_arb(x2, back[i][j]);
	go_front_arb(x1, i);
	go_front_arb(x2, i);
	x1[label[back[i][0]]] = back_type[i][0];
	x2[label[back[i][j]]] = back_type[i][j];
	if (calcEC(x2) != calcF(x2)) x1 = x2;
	assert(calcEC(x1) != calcF(x1));
	cout << "NO\n";
	for (int k = 0; k < m; ++k) cout << x1[k];
	cout << "\n";
	return 0;
      }
    }		     
  }
  int64 all_edges_hash = 0;
  for (int i = 0; i < m; ++i) all_edges_hash ^= weight[i];
  // not all edges checked on a path to t1. by flipping unchecked edge
  // we can get two colorings with different values of calcEC
  // and identical values of calcF
  if (edge_set_hash[t1] != all_edges_hash) {
    vector<int> x(m, -1);
    go_front_arb(x, s);
    vector<int> xprime = x;
    int fnon = 0;
    while (fnon < m && x[fnon] != -1) fnon++;
    assert(fnon < m);
    x[fnon] = 0;
    xprime[fnon] = 1;
    for (int i = fnon+1; i < m; ++i) 
      if (x[i] == -1) x[i] = xprime[i] = 0;
    if (calcEC(xprime) != calcF(xprime)) x = xprime;
    assert(calcEC(x) != calcF(x));
    cout << "NO\n";
    for (int i = 0; i < m; ++i) cout << x[i];
    cout << "\n";
    return 0;
  }
  
  // all paths to t1 produce wrong coloring of vertices. we just pick
  // an arbitrary path and print it.
  if (labels_hash[t1] != 0) {
    vector<int> x(m, -1);
    go_front_arb(x, s);
    //cerr << "wrong labels in t1\n";
    cout << "NO\n";
    for (int i = 0; i < m; ++i) cout << x[i];
    cout << "\n";
    return 0;
  }
  
  // we've checked that if 1-BP prints '1', then it is indeed 1
  // now we need to check that 1-BP never prints zero if the answer
  // is one. We will check every edge that goes from a vertex that
  // is reachable from t1 by back edges to a vertex that is not.
  // We need to check that on the end of such edge a component with
  // odd sum appears in G (when we delete all checked edges and modify
  // vertex labels accordingly).
  vector<bool> used(N, false);
  DSU dsu(v);
  for (int i = 0; i < v; ++i) dsu.odd[i] = c[i];
  tuple<int,int,int> result = make_tuple(-1,-1,-1);
  find_false_negative(t1, dsu, used, result);
  if (get<0>(result) != -1) {
    int i = get<0>(result);
    int j = get<2>(result);
    vector<int> x(m, -1);
    go_back_arb(x, i);
    x[label[i]] = j;
    vector<int> start_c(v, 0);
    for (int k = 0; k < v; ++k) start_c[k] = c[k];
    for (int k = 0; k < m; ++k) 
      if (x[k] == 1) {
	start_c[efrom[k]] ^= 1;
	start_c[eto[k]] ^= 1;	    
      }
    vector<int> y(m, 0);
    graphG::find_a_1_input_partial(y, x, start_c);
    for (int k = 0; k < m; ++k)
      if (x[k] == -1) {
	assert(y[k] != -1);
	x[k] = y[k];
      }
    
    assert(calcF(x) == 1);
    cout << "NO\n";
    for (int k = 0; k < m; ++k) cout << x[k];
    cout << "\n";
    return 0;
  }
 
  
  cout << "YES\n";
}

