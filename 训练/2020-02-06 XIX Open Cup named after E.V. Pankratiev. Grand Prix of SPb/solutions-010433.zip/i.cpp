#ifdef DEBUG
#define _GLIBCXX_DEBUG
#endif

#include <bits/stdc++.h>

using namespace std;

typedef long double ld;

#ifdef DEBUG
#define eprintf(...) fprintf(stderr, __VA_ARGS__), fflush(stderr)
#else
#define eprintf(...) ;
#endif

#define sz(x) ((int) (x).size())
#define TASK "text"

const int inf = (int) 1.01e9;
const long long infll = (long long) 1.01e18;
const ld eps = 1e-9;
const ld pi = acos((ld) -1);

mt19937 mrand(random_device{} ()); 

unsigned int rnd(unsigned int x) {
  return mrand() % x;
}

void precalc() {
}

const unsigned int mod = (1u << 31);

pair<long long, long long> gcd(long long a, long long b) {
  if (!b) {
    return make_pair(1ll, 0ll);
  }
  pair<long long, long long> p = gcd(b, a % b);
  return make_pair(p.second, p.first - (a / b) * p.second);
}

unsigned int inv(unsigned int x) {
  long long res = gcd(x, mod).first;
  if (res < 0) {
    res += mod;
  }
  return res;
}

const int maxn = (int) 1e5 + 5;
int n;

int read() {
  if (scanf("%d", &n) < 1) {
    return false;
  }
  return true;
}

set<unsigned int> used;
unsigned int a[maxn];
unsigned int b[maxn];

void solve() {
  used.clear();
  for (int i = 0; i < n; i++) {
    a[i] = rnd(mod);
    while (!(a[i] & 1) || used.count(a[i])) {
      a[i] = rnd(mod);
    }
    used.insert(a[i]);
    printf("%u ", a[i]);
  }
  printf("\n");
  fflush(stdout);
  for (int i = 0; i < n / 2; i++) {
    scanf("%u", &b[i]);
  }
  for (int i = 0; i < n; i++) {
    unsigned int x = (b[0] * inv(a[i])) % mod;
    unsigned int invx = inv(x);
    bool ok = true;
    for (int j = 1; j < n / 2; j++) {
      if (!used.count((b[j] * invx) % mod)) {
        ok = false;
        break;
      }
    }
    if (ok) {
      printf("%u\n", x);
      fflush(stdout);
      return;
    }
  }
  assert(false);
}

int main() {
  precalc();
  read();
  solve();
#ifdef DEBUG
  eprintf("Time %.2f\n", (double) clock() / CLOCKS_PER_SEC);
#endif
  return 0;
}
