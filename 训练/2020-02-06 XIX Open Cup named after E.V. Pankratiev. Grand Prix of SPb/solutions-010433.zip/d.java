import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.StringTokenizer;

public class opencup_19_2_D {
    static long a;
    static long b;

    static long[][][] s = new long[][][] {
            {{0, 0}, {0, 0}, {1, 0}, {1, -1}, {2, -1}},
            {{0, 0}, {1, 0}, {1, 0}, {1, 0}, {2, 0}},
            {{0, 1}, {1, 1}, {1, 0}, {2, 0}, {2, 0}},
            {{1, 1}, {1, 1}, {1, 1}, {2, 1}, {2, 0}},
            {{1, 2}, {1, 1}, {2, 1}, {2, 1}, {2, 1}},
    };

    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        PrintWriter pw = new PrintWriter(System.out);

        StringTokenizer st = new StringTokenizer(br.readLine());
        long x1 = Integer.parseInt(st.nextToken());
        long y1 = Integer.parseInt(st.nextToken());
        convert(x1, y1);

        long ta = a;
        long tb = b;

        st = new StringTokenizer(br.readLine());
        long x2 = Integer.parseInt(st.nextToken());
        long y2 = Integer.parseInt(st.nextToken());
        convert(x2, y2);

        pw.println(Math.abs(ta - a) + Math.abs(tb - b));

        pw.close();
    }

    public static void convert(long x, long y) {
        x += 1000000000L;
        y += 1000000000L;

        a = 0;
        b = 0;

        a += (y / 5);
        b += (y / 5) * 2;
        y %= 5;

        a += (x / 5) * 2;
        b -= (x / 5);
        x %= 5;

        a += s[(int)y][(int)x][0];
        b += s[(int)y][(int)x][1];
    }
}

