


#include "bits/stdc++.h"

using namespace std;

typedef long long int64;

#define x first
#define y second
typedef pair<int,int> pii;

const int maxn = 20;
int n, k, C;
vector<int> a[maxn];
vector<int> b[maxn];

int64 calculateVolume(vector<int> L, vector<int> R, 
                      int mask, int64 mod, int curp = -1) {
	    
  int64 ans = 0LL;
  int64 sign = (__builtin_popcount(mask) & 1 ? 1LL : -1LL);
  vector<int> curL = L;
  vector<int> curR = R;
  if (curp != -1) {
    if ((mask>>curp)&1) {
      for (int j = 0; j < k; ++j) {
	curL[j] = max(curL[j], a[curp][j]);
	curR[j] = min(curR[j], b[curp][j]);
      }
    } 
  }
  int64 invol = 1LL;
  for (int i = 0; i < k && invol != 0LL; ++i) {
    if (curL[i] >= curR[i]) invol = 0LL;
    else invol = (invol * (int64)(curR[i] - curL[i])) % mod;
  }
  if (mask != 0) ans = (ans + sign * invol + mod) % mod;
  /*cerr << "calculateVolume(";
    for (int j = 0; j < k; ++j) cerr << L[j] << " ";
    cerr << ", ";
    for (int j = 0; j < k; ++j) cerr << R[j] << " ";
    cerr << ", mask=" << mask;
    cerr << ") = ";
    cerr << ans << endl;*/
  if ((ans != 0 || mask == 0) && curp < n - 1) {
    for (int nxt = curp+1; nxt < n; ++nxt)
      ans = (ans + calculateVolume(curL, curR, mask | (1<<(nxt)), mod,
                                 nxt)) % mod;
    
  }
  
 
    
  
  return ans;
}

int64 calcCube(vector<int> L, vector<int> R, int64 mod) {
  int64 Uvolume = 1LL;
  for (int i = 0; i < k; ++i) 
    Uvolume = (Uvolume * int64(R[i]-L[i])) % mod;
  return Uvolume;
}

int main() {  
  cin >> n >> k >> C;
  for (int i = 0; i < n; ++i) {
    a[i].resize(k);
    b[i].resize(k);
    for (int j = 0; j < k; ++j) cin >> a[i][j];
    for (int j = 0; j < k; ++j) cin >> b[i][j];
    for (int j = 0; j < k; ++j) assert(a[i][j] < b[i][j]);        
  }
  vector<int64> mods = {int64(1e9 + 9), int64(1e9 + 7), 99990001};
  bool eq = true;
  for (int m = 0; m < (int)mods.size() && eq; ++m) {
    int64 Uvolume = calcCube(vector<int>(k,0),
                             vector<int>(k,C), mods[m]);
    if (Uvolume != calculateVolume(vector<int>(k,0), vector<int>(k,C),
				   0, mods[m])) eq = false;
  }
  if (eq) {
    cout << "NO\n";
    return 0;
  }
  vector<int> L(k,0);
  vector<int> R(k,C);
  for (int i = 0; i < k; ++i) {
    while (R[i] - L[i] > 1) {
      int m = (R[i] + L[i]) / 2;
      vector<int> Rprime = R;
      Rprime[i] = m;
      bool eq = true;
      for (int mod = 0; mod < (int)mods.size() && eq; ++mod) {
	if (calcCube(L, Rprime, mods[mod]) !=
	    calculateVolume(L, Rprime, 0, mods[mod])) eq = false;
      }
      if (!eq) R[i] = m;
      else L[i] = m;
    }
  }
  cout << "YES\n";
  for (int i = 0; i < k; ++i) cout << L[i] << " \n"[i==k-1];
}

